# SAEPVision

## Ferramentas
- Visual Studio Code
- Node.js (versão LTS)
- MySQL Server e MySQL Workbench

## Instalação
1. Abra esta pasta no VS Code.
2. Crie o banco executando `database.sql` no MySQL Workbench.
3. Copie `.env.example` para `.env` e ajuste usuário/senha do MySQL.
4. No terminal do VS Code execute `npm install`.
5. Execute `npm start`.
6. Acesse http://localhost:3000.

O servidor importa os seis usuários do CSV na primeira inicialização. Credenciais do material:
- fotografo1@email.com / 123456
- fotografo2@gmail.com / 123456
- fotografo3@gmail.com / 123456
- usuario1@gmail.com / 123456
- usuario2@gmail.com / 123456
- usuario3@gmail.com / 123456

Somente fotógrafos podem cadastrar/excluir suas publicações. Qualquer usuário autenticado pode curtir, com uma curtida por publicação. A pesquisa e o modal de autenticação seguem o enunciado.
