
require('dotenv').config();

const express = require('express');
const session = require('express-session');
const cors = require('cors');
const mysql = require('mysql2/promise');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({
    origin: true,
    credentials: true
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: process.env.SESSION_SECRET || 'visionsaep-dev-secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        sameSite: 'lax'
    }
}));

app.use('/assets', express.static(path.join(__dirname, 'public/assets')));
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));
app.use(express.static(path.join(__dirname, 'public')));

let db;

async function init() {
    db = await mysql.createPool({
        host: process.env.DB_HOST || 'localhost',
        port: Number(process.env.DB_PORT) || 3306,
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || '',
        database: process.env.DB_NAME || 'visionsaep',
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
    });

    await db.query(`
        CREATE TABLE IF NOT EXISTS tb_usuario (
            id_usuario INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            nome_usuario VARCHAR(60) NOT NULL UNIQUE,
            email VARCHAR(150) NOT NULL UNIQUE,
            senha VARCHAR(255) NOT NULL,
            imagem_usuario VARCHAR(255) DEFAULT 'usuario-padrao.jpg',
            tipo ENUM('fotografo','usuario') NOT NULL DEFAULT 'usuario',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    `);

    await db.query(`
        CREATE TABLE IF NOT EXISTS tb_publicacao (
            id_publicacao INT AUTO_INCREMENT PRIMARY KEY,
            id_usuario INT NOT NULL,
            titulo VARCHAR(150) NOT NULL,
            local_foto VARCHAR(150) NOT NULL,
            imagem VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_publicacao_usuario
            FOREIGN KEY (id_usuario)
            REFERENCES tb_usuario(id_usuario)
            ON DELETE CASCADE
        )
    `);

    await db.query(`
        CREATE TABLE IF NOT EXISTS tb_curtida (
            id_curtida INT AUTO_INCREMENT PRIMARY KEY,
            id_usuario INT NOT NULL,
            id_publicacao INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uk_curtida_usuario_publicacao (id_usuario, id_publicacao),
            CONSTRAINT fk_curtida_usuario
            FOREIGN KEY (id_usuario)
            REFERENCES tb_usuario(id_usuario)
            ON DELETE CASCADE,
            CONSTRAINT fk_curtida_publicacao
            FOREIGN KEY (id_publicacao)
            REFERENCES tb_publicacao(id_publicacao)
            ON DELETE CASCADE
        )
    `);

    console.log('MySQL conectado.');
}

const uploadDirectory = path.join(__dirname, 'public/uploads');

fs.mkdirSync(uploadDirectory, { recursive: true });

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDirectory);
    },

    filename: (req, file, cb) => {
        const extensao = path.extname(file.originalname).toLowerCase();
        const nome = Date.now() + '-' +
            Math.random().toString(16).slice(2) + extensao;

        cb(null, nome);
    }
});

const upload = multer({
    storage,
    limits: {
        fileSize: 8 * 1024 * 1024
    },
    fileFilter: (req, file, cb) => {
        const permitidos = [
            'image/jpeg',
            'image/png',
            'image/gif',
            'image/webp'
        ];

        if (permitidos.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error('Formato de imagem não permitido.'));
        }
    }
});

const auth = (req, res, next) => {
    if (!req.session.user) {
        return res.status(401).json({
            erro: 'Faça login para continuar.'
        });
    }

    next();
};

app.get('/api/me', (req, res) => {
    res.json({
        usuario: req.session.user || null
    });
});

app.post('/api/login', async (req, res, next) => {
    try {
        const { email, senha } = req.body;

        if (!email || !senha) {
            return res.status(400).json({
                erro: 'E-mail e senha são obrigatórios.'
            });
        }

        const [usuarios] = await db.query(
            `SELECT id_usuario, nome, nome_usuario, email,
            senha, imagem_usuario, tipo
            FROM tb_usuario WHERE email = ?`,
            [email.trim()]
        );

        if (!usuarios.length || usuarios[0].senha !== senha) {
            return res.status(401).json({
                erro: 'E-mail ou senha incorretos.'
            });
        }

        const { senha: senhaUsuario, ...usuario } = usuarios[0];

        req.session.user = usuario;

        res.json({
            usuario
        });
    } catch (error) {
        next(error);
    }
});

app.post('/api/logout', auth, (req, res) => {
    req.session.destroy(error => {
        if (error) {
            return res.status(500).json({
                erro: 'Não foi possível sair da conta.'
            });
        }

        res.clearCookie('connect.sid');
        res.json({ ok: true });
    });
});

app.get('/api/publicacoes', async (req, res, next) => {
    try {
        const uid = req.session.user?.id_usuario || 0;

        const [publicacoes] = await db.query(`
            SELECT
                p.*,
                u.nome,
                u.nome_usuario,
                (
                    SELECT COUNT(*)
                    FROM tb_curtida c
                    WHERE c.id_publicacao = p.id_publicacao
                ) AS curtidas,
                EXISTS (
                    SELECT 1
                    FROM tb_curtida c
                    WHERE c.id_publicacao = p.id_publicacao
                    AND c.id_usuario = ?
                ) AS curtida_usuario
            FROM tb_publicacao p
            JOIN tb_usuario u
            ON u.id_usuario = p.id_usuario
            ORDER BY p.created_at DESC
        `, [uid]);

        res.json(publicacoes);
    } catch (error) {
        next(error);
    }
});

app.get('/api/fotografos/:nome/publicacoes', async (req, res, next) => {
    try {
        const [publicacoes] = await db.query(`
            SELECT
                p.*,
                u.nome,
                u.nome_usuario,
                (
                    SELECT COUNT(*)
                    FROM tb_curtida c
                    WHERE c.id_publicacao = p.id_publicacao
                ) AS curtidas
            FROM tb_publicacao p
            JOIN tb_usuario u
            ON u.id_usuario = p.id_usuario
            WHERE u.nome_usuario = ?
            ORDER BY p.created_at DESC
        `, [req.params.nome]);

        res.json(publicacoes);
    } catch (error) {
        next(error);
    }
});

app.post('/api/publicacoes', auth, upload.single('imagem'), async (req, res, next) => {
    try {
        if (req.session.user.tipo !== 'fotografo') {
            if (req.file) {
                fs.unlinkSync(req.file.path);
            }

            return res.status(403).json({
                erro: 'Somente fotógrafos podem publicar fotografias.'
            });
        }

        const { titulo, local_foto } = req.body;

        if (!titulo || !local_foto || !req.file) {
            if (req.file) {
                fs.unlinkSync(req.file.path);
            }

            return res.status(400).json({
                erro: 'Preencha o título, o local e selecione uma fotografia.'
            });
        }

        const [resultado] = await db.query(`
            INSERT INTO tb_publicacao
            (id_usuario, titulo, local_foto, imagem)
            VALUES (?, ?, ?, ?)
        `, [
            req.session.user.id_usuario,
            titulo.trim(),
            local_foto.trim(),
            req.file.filename
        ]);

        res.status(201).json({
            ok: true,
            mensagem: 'Fotografia publicada com sucesso!',
            id_publicacao: resultado.insertId,
            imagem: req.file.filename
        });

    } catch (error) {
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }

        next(error);
    }
});

app.delete('/api/publicacoes/:id', auth, async (req, res, next) => {
    try {
        const [publicacoes] = await db.query(
            'SELECT imagem, id_usuario FROM tb_publicacao WHERE id_publicacao = ?',
            [req.params.id]
        );

        if (!publicacoes.length) {
            return res.status(404).json({
                erro: 'Publicação não encontrada.'
            });
        }

        if (Number(publicacoes[0].id_usuario) !== Number(req.session.user.id_usuario)) {
            return res.status(403).json({
                erro: 'Você só pode excluir suas próprias publicações.'
            });
        }

        await db.query(
            'DELETE FROM tb_publicacao WHERE id_publicacao = ?',
            [req.params.id]
        );

        const arquivo = path.join(uploadDirectory, path.basename(publicacoes[0].imagem));

        if (fs.existsSync(arquivo)) {
            fs.unlinkSync(arquivo);
        }

        res.json({ ok: true });

    } catch (error) {
        next(error);
    }
});

app.post('/api/curtidas/:id', auth, async (req, res, next) => {
    try {
        const id = Number(req.params.id);
        const uid = req.session.user.id_usuario;

        if (!Number.isInteger(id) || id <= 0) {
            return res.status(400).json({
                erro: 'Publicação inválida.'
            });
        }

        const [publicacoes] = await db.query(
            'SELECT id_publicacao FROM tb_publicacao WHERE id_publicacao = ?',
            [id]
        );

        if (!publicacoes.length) {
            return res.status(404).json({
                erro: 'Publicação não encontrada.'
            });
        }

        const [curtidas] = await db.query(
            'SELECT id_curtida FROM tb_curtida WHERE id_usuario = ? AND id_publicacao = ?',
            [uid, id]
        );

        if (curtidas.length) {
            await db.query(
                'DELETE FROM tb_curtida WHERE id_usuario = ? AND id_publicacao = ?',
                [uid, id]
            );
        } else {
            await db.query(
                'INSERT INTO tb_curtida (id_usuario, id_publicacao) VALUES (?, ?)',
                [uid, id]
            );
        }

        const [[total]] = await db.query(
            'SELECT COUNT(*) AS total FROM tb_curtida WHERE id_publicacao = ?',
            [id]
        );

        res.json({
            curtida: !curtidas.length,
            total: total.total
        });

    } catch (error) {
        next(error);
    }
});

app.get('/api/perfil', auth, async (req, res, next) => {
    try {
        if (req.session.user.tipo !== 'fotografo') {
            return res.status(403).json({
                erro: 'Perfil disponível apenas para fotógrafos.'
            });
        }

        const uid = req.session.user.id_usuario;

        const [[publicacoes]] = await db.query(
            'SELECT COUNT(*) AS total FROM tb_publicacao WHERE id_usuario = ?',
            [uid]
        );

        const [[likes]] = await db.query(`
            SELECT COUNT(c.id_curtida) AS total
            FROM tb_curtida c
            JOIN tb_publicacao p
            ON p.id_publicacao = c.id_publicacao
            WHERE p.id_usuario = ?
        `, [uid]);

        res.json({
            publicacoes: publicacoes.total,
            likes: likes.total
        });

    } catch (error) {
        next(error);
    }
});

app.get('/api/busca/:nome', async (req, res, next) => {
    try {
        const termo = req.params.nome.trim();

        const [usuarios] = await db.query(`
            SELECT id_usuario, nome, nome_usuario, imagem_usuario
            FROM tb_usuario
            WHERE tipo = 'fotografo'
            AND (nome LIKE ? OR nome_usuario LIKE ?)
            ORDER BY nome
        `, [`%${termo}%`, `%${termo}%`]);

        res.json(usuarios);

    } catch (error) {
        next(error);
    }
});

app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.use((error, req, res, next) => {
    console.error('Erro:', error);

    if (error instanceof multer.MulterError) {
        const mensagem = error.code === 'LIMIT_FILE_SIZE'
            ? 'A imagem deve ter no máximo 8 MB.'
            : 'Erro ao enviar a imagem.';

        return res.status(400).json({ erro: mensagem });
    }

    res.status(500).json({
        erro: error.message || 'Erro interno do servidor.'
    });
});

async function iniciarServidor() {
    try {
        await init();

        app.listen(PORT, () => {
            console.log(`SAEPVision disponível em http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error('Erro ao iniciar servidor:', error.message);
        process.exit(1);
    }
}

iniciarServidor();
