
CREATE DATABASE IF NOT EXISTS visionsaep
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE visionsaep;

CREATE TABLE IF NOT EXISTS tb_usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    nome_usuario VARCHAR(60) NOT NULL UNIQUE,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    imagem_usuario VARCHAR(255) DEFAULT 'usuario-padrao.jpg',
    tipo ENUM('fotografo','usuario') NOT NULL DEFAULT 'usuario',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tb_publicacao (
    id_publicacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    local_foto VARCHAR(150) NOT NULL,
    imagem VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_publicacao_usuario
    FOREIGN KEY (id_usuario)
    REFERENCES tb_usuario(id_usuario)
    ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tb_curtida (
    id_curtida INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_publicacao INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_curtida_usuario_publicacao (id_usuario, id_publicacao),
    CONSTRAINT fk_curtida_usuario
    FOREIGN KEY (id_usuario)
    REFERENCES tb_usuario(id_usuario)
    ON DELETE CASCADE,
    CONSTRAINT fk_curtida_publicacao
    FOREIGN KEY (id_publicacao)
    REFERENCES tb_publicacao(id_publicacao)
    ON DELETE CASCADE
);

UPDATE tb_usuario SET email = 'anaclara.fotografia@gmail.com'
WHERE nome_usuario = 'fotografo_1';

UPDATE tb_usuario SET email = 'beatriz.fotografia@gmail.com'
WHERE nome_usuario = 'fotografo_2';

UPDATE tb_usuario SET email = 'camilasantos@gmail.com'
WHERE nome_usuario = 'fotografo_3';

UPDATE tb_usuario SET email = 'mariana.costa@gmail.com'
WHERE nome_usuario = 'usuario_1';

UPDATE tb_usuario SET email = 'lucas.ferreira@gmail.com'
WHERE nome_usuario = 'usuario_2';

UPDATE tb_usuario SET email = 'rafael.almeida@gmail.com'
WHERE nome_usuario = 'usuario_3';

INSERT INTO tb_publicacao
(titulo, local_foto, imagem, id_usuario)
SELECT
    'Floresta',
    'Bahia',
    '1794343342064-09e5b523946f18.jpg',
    id_usuario
FROM tb_usuario
WHERE nome_usuario = 'fotografo_1'
AND NOT EXISTS (
    SELECT 1 FROM tb_publicacao
    WHERE titulo = 'Floresta'
    AND imagem = '1794343342064-09e5b523946f18.jpg'
);

INSERT INTO tb_publicacao
(titulo, local_foto, imagem, id_usuario)
SELECT
    'Polos',
    'Alasca',
    '1794343318843-45c8e7ae6c646.jpg',
    id_usuario
FROM tb_usuario
WHERE nome_usuario = 'fotografo_1'
AND NOT EXISTS (
    SELECT 1 FROM tb_publicacao
    WHERE titulo = 'Polos'
    AND imagem = '1794343318843-45c8e7ae6c646.jpg'
);

INSERT INTO tb_publicacao
(titulo, local_foto, imagem, id_usuario)
SELECT
    'Paisagem dinâmica',
    'Dinamarca',
    '1794343304255-dde729079e653.jpg',
    id_usuario
FROM tb_usuario
WHERE nome_usuario = 'fotografo_1'
AND NOT EXISTS (
    SELECT 1 FROM tb_publicacao
    WHERE titulo = 'Paisagem dinâmica'
    AND imagem = '1794343304255-dde729079e653.jpg'
);

SELECT * FROM tb_usuario;
SELECT * FROM tb_publicacao;
SELECT * FROM tb_curtida;
